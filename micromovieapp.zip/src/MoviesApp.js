import { useState } from "react";
import {movies as moviesList} from "./data.js"
import Search from "./Search.js"
import MovieCard from "./MovieCard.js"

export const MoviesApp=()=>{
    const[movies,setMovies]=useState(moviesList);

    const searchMovies=(searchValue)=>{
        //filter movies which are a match of search value
        const filterdMovies=moviesList.filter((movie)=>{
            return movie.Title.toLowerCase().includes(searchValue.toLowerCase())
        });
        setMovies(filterdMovies);
    }
    return(
        <>
        <Search searchMovies={searchMovies}/>
        <div className="movie-cards">
            {
            movies.map(movie=><MovieCard movieInfo={movie} key={movie.imdbID}/>)
            }

        </div>
        </>
    )
}