// const url="https://dummyjson.com/products";

// fetch(url)
// .then((responseObj)=>{
//     return responseObj.json();//we have to convert the response data to json
// })
// .then((result)=>{
//     console.log(result.products);//this is the data sent back through the fetch
// })
// .catch((err)=>{
//     console.log(err);
// });

// async function test1(){
//     return "he;llo"
// }
// test1()
// .then((data)=>{
//     console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })

// function test2(){
//     return "helloie"
// }
// console.log(test1());
// console.log(test2());

// const p1=new Promise((resolve,reject)=>{
//     resolve("hello");
// })

// async function test1(){
//     return p1;
// }
// test1()
// .then((data)=>{
//     console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })
// console.log(test1());
// console.log(p1);

// console.log("start");
// function intro(name){
//     return new Promise((resolve, reject)=>{
//         const condition=true;
//         if (condition) {
//             setTimeout(() => {
//                 resolve(`Hi i am ${name}`)
//             }, 2000);
//         }else{
//             setTimeout(() => {
//                 reject("sorrry no intro")
//             }, 2000);
//         }
//     })
// }
// console.log("mid");
// async function handlePromise(){
//     try{
//       console.log( await intro("nitish"));
//     }catch(error){
//         console.log(error);
//     }
//     }


// console.log(handlePromise()); //the presence of the promise here is a sign that the
// //await is working, it doesnt disrupt the thread, it waits for the promise to be settled
// //then it produces the results
// //the entire function surrounding the await is thrown out of the GEC 

// console.log("eend");


// const url="https://airbnb13.p.rapidapi.com/search-location?location=Paris&checkin=2024-09-16&checkout=2024-09-17&adults=1&children=0&infants=0&pets=0&page=1&currency=USD";
// const options={
//     method:"GET",
//     headers:{ 
//     "X-RapidAPI-Key": "65e22afc84msh1fa2987821b194dp1fc6a6jsn17d4b8079803",
//     "X-RapidAPI-Host": "airbnb13.p.rapidapi.com",
//     }
// };

// async function getData(){
//     try {
//         const response=await fetch(url,options);
//         const result=await response.json();
//         console.log(result.results);
//         renderData(result.results)
//     } catch (error) {
//         console.log(error);
//     }
// }

// function renderData(arrayOfHotel) {
//     arrayOfHotel.forEach(hotel => {
//         const hotelDiv = document.createElement("div");
//         const title = document.createElement("h1");
//         title.innerHTML = hotel.name;
//         title.appendChild(hotelDiv);
//     });
// }

// getData();


