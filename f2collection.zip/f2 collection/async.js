//sync
// console.log('start');
// console.log('mid');
// console.log('end');

//async
// console.log("start");
// setTimeout(() => {
//   console.log("mid");
// }, 2000);
// console.log("end");

// console.log("start");

// function intro(name){
// //async
// setTimeout(()=>{
//     return `Hi i am ${name}`
// },2000)
// //sync
// // return "sync element"
// }
// const introM=intro("mayoka");
// console.log(introM);
// //it returns undefined because its value is not being captured, however its sync value is undefined
// console.log("end");

//callback hack
console.log("start");

function intro(name,cb){
    setTimeout(()=>{
        cb(`Hi i am ${name}`)
    },2000);
}
// intro("mayoka",(result)=>{
//     console.log(result);
// })

// console.log("end");
//here we hack the callback by using a call back function that is called
// when the setitmeout ends, the call back function captures the values of the set timeout

function whereDoIStudy(edTechName,cw){
    setTimeout(()=>{
        cw(`Hi i study at ${edTechName}`)
    },500);
}

function birthPlace(city,cp){
    setTimeout(()=>{
        cp(`My birth Place ${city}`);
    },1000)
}

intro("mayoka",(result)=>{
    console.log(result);
    whereDoIStudy("MUBS",(result)=>{
        console.log(result);
        birthPlace("mbale",(result)=>{
            console.log(result);
        })
    })
})




console.log("end");


// intro---------2s
// whereDoIStudy-0.5s
// birthPlace---1s