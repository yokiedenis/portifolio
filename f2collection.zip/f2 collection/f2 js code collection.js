// table of content
// 1...prime number
// 2...level in dom
// 3...Colourful String
// 4...article Less array
// 5...second smallest element
// 6...factorial
// 7...random qoutes
// 8...password strength
// 9...firstNonRepeatedChar
// 10...maximum frequency
// 11...peak Element
// 12...infinite scroll
// 13...level
// 14...convertToHrs
// 15...instagram


// prime number.......................................1

// const array = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

// function isPrime(num) {
//   for (let i = 2; num > i; i++) {
//     if (num % i === 0) {
//       return false;
//     }
//   }
//   return num > 1;
// }

// console.log(array.filter(isPrime)); // [2, 3, 5, 7, 11, 13]

// level in dom/...................................2

// const levelElement = document.getElementById("level");
// let level = 1;

// while (true) {
//   if ((levelElement.tagName = "HTML")) {
//     break;
//   }
//   levelElement = levelElement.parentNode;
//   level++;
// }

// alert(`The level of the element is: ${level}`);

// Colourful String....................................3
// function colorfulSubsequences(s) {
//   const frequencies={};
// 	let count=1;
// 	for (let char of s) {
// 		frequencies[char]=(frequencies[char]||0)+1;
// 	}
// 	for(let key in frequencies){
// 		count=count*(frequencies[key]+1)%11092019;
// 	}
// 	return count;
// }



// 4------------------------article Less array--------------------------4
// let arr=[
//     "The Virupasksha Temple",
//     "a Victoria Memorial",
//     "an Tajmahal"
// ];
// let articleLessArray=[];
// let anotherObject={};
// //console.log(arr);
// for (let i= 0; i< arr.length; i++) {
//     let aLessItem=arr[i].replace(/\bthe\b|\ban\b|\ba\b/gi,"").trim();
//     articleLessArray.push(aLessItem);
//     anotherObject[aLessItem]=arr[i];
// }
// console.log(anotherObject);
// console.log(articleLessArray);
// articleLessArray.sort();

// let ans = [];

// for (let i of articleLessArray) {
//   ans.push(anotherObject[i]);
// }

// console.log(ans);


//5-------------------------second smallest element----------------------5

// let arr = [3, 10, 9, 12, 18, 5];
// //                i=2

// let a = arr[0],
//   b = arr[1];

// for (let i = 2; i < arr.length; i++) {
//   let currentMax = a > b ? a : b; //3
//   let currentMin = a < b ? a : b; //

//   if (currentMax > arr[i]) {
//     a = currentMin; // a = 3
//     b = arr[i]; // b = 9
//   }
// }

// console.log(a > b ? a : b);


//6----------------------------factorial---------------------------6
// function factorial(n) {
//     if (n == 0) return 1;
//     return n * factorial(n - 1);
// }


//7---------------------------------random qoutes-----------------------7
// function randomQoutes() {
//     const qoutes = ["life isn't about black and white,look around and you will see that the world is much more colorful than you thought",
//         "Progress is quiet until it isn't",
//         "And sometimes it's as simple as changing your environment.",
//         "Every battle is lost or won in the arena of the mind",
//         "Yes, you may love them to death, but are they willing to love you to life?",
//         "Time the time before the time time you",
//         "Life is an outward projection of one's perceived self value"
//     ];
//     const randomIndex = Math.floor(Math.random() * qoutes.length);
//     console.log(qoutes[randomIndex]);
// }
// randomQoutes();


//8-----------------------password strength-------------------------8
// function psc(password){
//     const strength=["very weak","weak","moderate","strong","very strong", "unbreakable"];
//     let score=0;
//     if(password.length>8)score++;
//     if(/[a,z]/.test(password))score++;
//     if(/[A,Z]/.test(password))score++;
//     if(/[0,9]/.test(password))score++;
//     if(/[!@#$%^&*()~`]/.test(password))score++;
//     return strength[score]; 
// }
// let passworduser=prompt("enter password: ");
// alert("your password is "+ psc(passworduser));

// //password generator
// function password_gene(numic){
//     const myset="ABCDEFGHIJKLMNOPRSTUVWXYZabcdefghijklmnoprstuvwxyz1234567890~!@#$%^&*()"
//     let resulty="";
//     for (let index = 0; index < numic; index++) {
//         let randomIndexy =Math.floor(Math.random()*myset.length);
//         let randomchar=myset[randomIndexy];
//         resulty+=randomchar;
//     }
//     return resulty;
// }
// let password_length=prompt("Enter the length of your password: ");
// alert(password_gene(password_length));



//9----------------------------firstNonRepeatedChar----------------------9
// let str1 ="aabbcc";//input string
// function firstNonRepeatedChar(str){//function to work with
//     let obj={};//create empty object to store string chars as keys
//     for(let i=0; i < str.length; i++){
//         if(obj[str[i]]!==undefined){
//             obj[str[i]]+=1;
//         }else{
//             obj[str[i]]=1;
//         }
//     }
//     for(let i=0;i<str.length;i++){
//         if(obj[str[i]]==1){
//             return str[i];
//         }
//     }
   
//     return null;
// }

// console.log(firstNonRepeatedChar(str1));



//10------------------------- maximum frequency of an element in a sorted array-----------------10

// let arr = [2, 2, 3, 5, 5, 5];
// let i = 0,
//   j = 0,
//   max = 1,
//   maxElement = arr[0];

// while (j < arr.length) {
//   if (arr[j] != arr[i]) {
//     i = j;
//     j++;
//     continue;
//   }
//   let currentMaxLength = j - i + 1;

//   if (max < currentMaxLength) {
//     max = currentMaxLength;
//     maxElement = arr[i];
//   }
//   j++;
// }

// console.log(max, maxElement);


//11----------------------------------- peak Element----------------------11

// let arr = [3, 5, 8, 4, 9, 7];
// if (arr.length >= 3) {
//   for (let i = 1; i < arr.length - 1; i++) {
//     if (arr[i] > arr[i + 1] && arr[i] > arr[i - 1]) {
//       console.log(arr[i], "is the peak element");
//       break;
//     }
//   }
// } else {
//   console.log("array length should be atleast 3");
// }

// Reverse an array
// let arr = [3, 7, 2, 9, 8];

// let i = 0,
//   j = arr.length - 1;

// while (i < j) {
//   let temp = arr[j];
//   arr[j] = arr[i];
//   arr[i] = temp;
//   console.log(i);
//   i++;
//   j--;
// }
// console.log(arr);



//12----------------------------------infinite scroll----------------------------12
// const scrollContainer = document.getElementById("container");
// let i = 0;
// function addOneItem() {
//   const li = document.createElement("li");
//   li.innerText = `Item ${++i}`;
//   scrollContainer.appendChild(li);
// }

// for (let i = 0; i < 10; i++) {
//   addOneItem();
// }

// scrollContainer.addEventListener("scroll", () => {
//   const maxScrollHeight =
//     scrollContainer.scrollHeight - scrollContainer.clientHeight;
//   let currentScrollTop = scrollContainer.scrollTop;

//   let threshold = Math.abs(maxScrollHeight - currentScrollTop);

//   if (threshold <= 5) {
//     for (let i = 0; i < 2; i++) {
//       addOneItem();
//     }
//   }
// });


//13------------------------------------level-------------------------------------13
// document.addEventListener("DOMContentLoaded", () => {
//   let levelElement = document.getElementById("level");
//   console.log(levelElement);
//   let level = 1;

//   while (true) {
//     if (levelElement.tagName === "HTML") {
//       break;
//     }
//     console.log(levelElement);
//     levelElement = levelElement.parentNode;
//     level++;
//   }

//   alert(`The level of the element is: ${level}`);
// });

//14---------------------------convertToHrs--------------------------14
// function convertToHrs(seconds) {
//   // seconds is the number of seconds
//   let totalMins = parseInt(seconds / 60);
//   let totalSeconds = seconds % 60;
//   let totalHrs = parseInt(totalMins / 60);
//   let finalMins = totalMins % 60;
//   return `${totalHrs}H: ${finalMins}M: ${totalSeconds}S`;
//   // return "01H: 20M: 30S"
// }

// console.log(convertToHrs(3829220));

//15-------------------------------instagram-------------------------------------15
// function onDragStart(event) {
//     event.dataTransfer.setData("sourceId", event.target.id);
//   }

// function onDrop(event) {
//     const sourceId = event.dataTransfer.getData("sourceId");
//     const sourceElement = document.getElementById(sourceId);
//     const destElement = event.target;
  
//     const sourceNextElement = sourceElement.nextElementSibling;
//     const destNextElement = destElement.nextElementSibling;
  
//     container.insertBefore(destElement, sourceNextElement);
  
//     container.insertBefore(sourceElement, destNextElement);
//   }
  

