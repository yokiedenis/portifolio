
// const p1 =new Promise((resolve,reject)=>{
//     const condition=true;
//     if (condition) {
//         setTimeout(() => {
//             resolve("this promise is now resolved")  
//         }, 1000);

       
//     }else{
//         setTimeout(() => {
//             reject("this promise failed")
//         }, 1000);
//     }
// })
// console.log("start");
// p1
// .then((data)=>{
// console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })
// console.log("end");

// function promise1(){
//     return new Promise((res,rej)=>{
//         const condition=true;
//         if (condition) {
//             res("p1")
//         }else{
//             rej("e1")
//         }
//     })
// }

// const p2 =new Promise((res,rej)=>{
//     const condition=true
//     if (condition) {
//         res("p2")
//     }else{
//         rej("e2")
//     }
// })

// p2.then((data)=>{
//     console.log(data);
//     return promise1();
// })
// .then((data)=>{
// console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })

// console.log("start");
// function intro(name){
//     return new Promise((resolve, reject)=>{
//         const condition=true ;
//         if(condition){
//             setTimeout(()=>{
//                 resolve(`Hi i am ${name}`)
//             },3000)
//         }else{
//             reject("sorry no intro");
//         }
//     });
// }

// function workPlace(companyName){
//     return new Promise ((resolve,reject)=>{
//     const condition=false;
//     if(condition){
//         setTimeout(() => {
//             resolve(`Hi i work at ${companyName}`)
//         }, 500);
//     }else{
//         reject("sorry no workplace")
//     }
//     });
// }

// function myCity(city){
//     return new Promise((resolve,reject)=>{
//       const  condition=true;
//       if(condition){
//         setTimeout(() => {
//             resolve(`hi i am from ${city}`)
//         }, 10000);
//       }else{
//         setTimeout(() => {
//             reject("sorry no city available")
//         }, 50000);
//       }
//     })
// }
// intro("rockey")
// .then((data)=>{
// console.log(data);
// workPlace("accio")
// .then((data)=>{
//     console.log(data);
//     myCity("mbale") 
//     .then((data)=>{
//         console.log(data);
//     })
//     .catch((err) => {
//         console.log(err);
//       });
// })
// .catch((err) => {
//     console.log(err);
//   });
// })
// .catch((err) => {
//     console.log(err);
//   });

// intro("rockey")
// .then((data)=>{
//     console.log(data);
//     return workPlace("accio")
// })
// .then((data)=>{
//     console.log(data);
//     return myCity("mbale")
// })
// .then((data)=>{
//     console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })





// myCity("mbale")
// .then((data)=>{
//     console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })

//calling each one individually
// intro("denis")
// .then((data)=>{
// console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })
// console.log("end");

// workPlace("acciojob")
// .then((data)=>{
//     console.log(data);
// })
// .catch((err)=>{
//     console.log(err);
// })

