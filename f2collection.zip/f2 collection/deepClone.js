//structered deep clone
const deepClone = (obj) => {
  const type = typeof obj;
  if (type !== "object" || obj == null) return obj;
  if (Array.isArray(obj)) {
    return obj.map((item) => deepClone(item));
  }
  let arrObj = Object.entries(obj);
  let deepCloneArrObj = arrObj.map(([key, value]) => [key, deepClone(value)]);
  return Object.fromEntries(deepCloneArrObj);
};

//easy deep clone
// JSON.parse(JSON.stringify(obj));


//call

// let obj = {
//     a: 10,
//   };
  
  
// function abc() {
//     console.log("inside window");
//     console.log('inside fn->',this);
//   }

//   console.log(obj);

//   abc.call(obj);
// console.log(obj);
// abc();


// let obj2 = {
//   obj3: {
//     ppoiui: 'this is obj3 string',
//   },
// };

// function test(...param){//rest
//   console.log(this);
//   console.log(...param);//spread
// };

// test.call(obj2,2,2,3,4,5,6,7,8);

// function abc(param1, param2, param3) {
//     console.log(this, param1, param2, param3);
//   }
  
//   let obj = {
//     a: 10,
//   };
  
//   // arg1=10, arg2=20, arg3=30
  
//   abc.call(obj, 10, 20, 30);
//   abc(10, 20, 30);
  
//apply is like call except fo it it takes an entire array as argument during invokation

//bind
// function f1(p,p2,p3){
//     console.log('sdfgh');
//     console.log(this,p,p2,p3);
// }

// let obj={
//     a:'this is obj',
// }

// const f2 = f1.bind(obj,1,2);//when we declare args at this level, they become permanent


// console.log(f2);

// f1();

// f2("ww","wws","ds");//stores f1 with context of obj 


// console.log(obj);