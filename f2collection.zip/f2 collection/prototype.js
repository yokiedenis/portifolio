// let arr = new Array();
// Object.prototype.someXYZ = "test";
// let obj={}
// function abc(){
// }

// let obj1 = {
//     nam: "parvez",
//   };
  
//   let obj2 = {
//     city: "Delhi",
//     nam: "pc",
//     getDetails() {
//       console.log(`Hi I am ${this.nam} and I am from ${this.city}`);
//     },
//   };

//   obj1.__proto__ = obj2;

// obj1.getDetails();

// obj2.getDetails();


//filter 
// delete Array.prototype.filter;

// Array.prototype.filter = function (callbackFn) {
//   const result = [];

//   for (let i = 0; i < this.length; i++) {
//     if (callbackFn(this[i], i, this)) {
//       result.push(this[i]);
//     }
//   }

//   return result;
// };

