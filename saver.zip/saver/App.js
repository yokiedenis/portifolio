
// //this is a default export so we can export it only once,
// //one default per page or js file
// //first we define it before export

// //when exporting functions keep capslock first letter 
// //we also keep smallcaps first for local components
// let SayHello;
// export default SayHello=()=>{
//   return <h1>Hello World</h1>
// }

// ////creating bold elements for practise
// const bold = <b>Bold text</b>;
// const bold1 = <b>Bold 1 text</b>;
// const bold2 = <b>Bold 2 text</b>;

// //we can put them in an array too
// // let arr = [bold, bold1, bold2]

// ////named export
// export const App =function ({id,className}) {
//   console.log(id,className);
//   return(
//     <p>
//             {bold}
//             {bold1}
//             {bold2} 
//             {/* {[bold, bold1, bold2]} */}
//             <span>Span text</span>
//         </p>
//     )
//   } 

//props
// export let Img=(props)=>{
//   console.log(props.propa,props);
//   return <h1>home is best</h1> 
// }