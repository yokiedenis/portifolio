import "material-icons/iconfont/material-icons.css"
import { useState } from "react";
import Input from "./input.js"
import Chip from "./Chip.js"
import "./skills.css"

// Never manipulate state directly yourself
export default function App(){
  console.log("parent render");
  const [skills,setSkills]=useState([]);

  const addSkill=(newSkill)=>{
    setSkills([...skills,newSkill]);
  }
  
  const deleteSkill=(skillTobeDeleted)=>{
    const remainingSkills=skills.filter((skill)=>skill !== skillTobeDeleted);
    setSkills(remainingSkills);
  }
  return(
    <div>
    <Input addSkill={addSkill}/>
    <div className="skills-container">
{
  skills.map((skill,index)=>
  <Chip deleteSkill={deleteSkill} key={index} skill={skill}/>)
}
    </div>
    </div>
  )
}